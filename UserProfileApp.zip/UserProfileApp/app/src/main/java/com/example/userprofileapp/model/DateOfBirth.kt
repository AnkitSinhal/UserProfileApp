package com.example.userprofileapp.model

data class DateOfBirth(val day : String, val month : String, val year : String)
