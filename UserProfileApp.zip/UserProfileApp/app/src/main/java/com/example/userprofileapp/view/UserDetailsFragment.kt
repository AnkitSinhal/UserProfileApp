package com.example.userprofileapp.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.userprofileapp.R
import com.example.userprofileapp.viewmodel.UserViewModel

class UserDetailsFragment : Fragment() {

    private lateinit var userViewModel: UserViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout
        val rootView = inflater.inflate(
            R.layout.fragment_user_details,
            container, false
        )

        userViewModel = ViewModelProvider(requireActivity()).get(UserViewModel::class.java)

        val firstName: TextView = rootView.findViewById(R.id.textViewFirstName)
        val lastName: TextView = rootView.findViewById(R.id.textViewLastName)
        val dob: TextView = rootView.findViewById(R.id.textViewDob)
        val backButton: Button = rootView.findViewById(R.id.buttonBack)

        userViewModel.userDataResponse.observe(viewLifecycleOwner, { it ->

            ("First name: " + it.firstName).also { firstName.text = it }
            ("Last name: " + it.lastName).also { lastName.text = it }

            if (it.dob != null) {
                val builder = StringBuilder()
                builder.append("Age: ").append("${it.dob.year} Years").append(" , ")
                    .append("${it.dob.month} Months").append(" , ")
                    .append("${it.dob.day} Days")
                dob.text = builder.toString()
            } else {
                dob.text = getString(R.string.invalid_date)
            }
        })

        backButton.setOnClickListener {
            onBackPressed()
        }

        return rootView
    }

    private fun onBackPressed() {
        requireActivity().supportFragmentManager.popBackStack()
    }

}
