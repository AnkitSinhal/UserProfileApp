package com.example.userprofileapp.view

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.userprofileapp.R
import com.example.userprofileapp.viewmodel.UserViewModel
import java.text.SimpleDateFormat
import java.util.*

class UserInputFragment : Fragment() {
    private lateinit var userViewModel: UserViewModel
    var cal = Calendar.getInstance()
    lateinit var mDatePickerText: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout
        val rootView = inflater.inflate(
            R.layout.fragment_user_input,
            container, false
        )

        userViewModel = ViewModelProvider(requireActivity()).get(UserViewModel::class.java)

        val firstName: EditText = rootView.findViewById(R.id.editTextViewFirstName)
        val lastName: EditText = rootView.findViewById(R.id.editTextViewLastName)
        mDatePickerText = rootView.findViewById(R.id.textDatePicker)
        val buttonNext: Button = rootView.findViewById(R.id.buttonNext)


        mDatePickerText.setOnClickListener {
            DatePickerDialog(
                rootView.context,
                dateSetListener,
                // set DatePickerDialog to point to today's date when it loads up
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        buttonNext.setOnClickListener {
            userViewModel.fetchUserProfile(
                firstName.text.toString().trim(),
                lastName.text.toString().trim(),
                cal
            )
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, UserDetailsFragment(), "UserDetailsFragment")
                .addToBackStack(null).commit()

        }
        return rootView
    }

    private val dateSetListener =
        DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, monthOfYear)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateDateInView()
        }

    private fun updateDateInView() {
        val sdf = SimpleDateFormat(getString(R.string.date_format), Locale.US)
        mDatePickerText.text = sdf.format(cal.time)
    }
}