package com.example.userprofileapp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.userprofileapp.model.DateOfBirth
import com.example.userprofileapp.model.UserData
import java.util.*


class UserViewModel : ViewModel() {
    private val _loginResponse: MutableLiveData<UserData> = MutableLiveData()
    val userDataResponse: LiveData<UserData>
        get() = _loginResponse


    fun fetchUserProfile(
        firstName: String,
        lastName: String,
        cal: Calendar
    ) {

        _loginResponse.value = UserData(firstName, lastName, calculateAge(cal))
    }

    private fun calculateAge(birthDay: Calendar): DateOfBirth? {
        val now = Calendar.getInstance()

        val diff: Long = (now.timeInMillis - birthDay.timeInMillis)
        if (diff < 0) {
            return null
        } else {
            // Get difference between years
            var years: Int = now.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR)
            val currMonth: Int = now.get(Calendar.MONTH) + 1
            val birthMonth: Int = birthDay.get(Calendar.MONTH) + 1

            // Get difference between months
            var months = currMonth - birthMonth

            // If month difference is negative then reduce years by one
            // and calculate the number of months.
            if (months < 0) {
                years--
                months = 12 - birthMonth + currMonth
                if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE)) months--
            } else if (months == 0 && now.get(Calendar.DATE) < birthDay.get(Calendar.DATE)) {
                years--
                months = 11
            }

            // Calculate the days
            var days = 0
            if (now.get(Calendar.DATE) > birthDay.get(Calendar.DATE)) days =
                now.get(Calendar.DATE) - birthDay.get(Calendar.DATE) else if (now.get(Calendar.DATE) < birthDay.get(
                    Calendar.DATE
                )
            ) {
                val today: Int = now.get(Calendar.DAY_OF_MONTH)
                months--
                days =
                    now.getActualMaximum(Calendar.DAY_OF_MONTH) - birthDay.get(Calendar.DAY_OF_MONTH) + today
            } else {
                days = 0
                if (months == 12) {
                    years++
                    months = 0
                }
            }
            // Display the age in years, months and days
            return DateOfBirth("$days", "$months", "$years")
        }
    }
}


