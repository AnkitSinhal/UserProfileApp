package com.example.userprofileapp.model

data class UserData(val firstName : String, val lastName : String, val dob : DateOfBirth?)
